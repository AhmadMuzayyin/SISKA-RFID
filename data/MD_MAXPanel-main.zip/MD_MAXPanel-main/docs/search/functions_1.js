var searchData=
[
  ['clear_0',['clear',['../class_m_d___m_a_x_panel.html#a052fa07a510eb92b6ffa3605f75a7dfd',1,'MD_MAXPanel::clear(void)'],['../class_m_d___m_a_x_panel.html#a17d910342f29983c059b4fad864d74c7',1,'MD_MAXPanel::clear(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2, bool state=false)']]]
];
