var _m_d___m_a_x_panel__lib_8h =
[
    [ "CHAR_SPACING_DEFAULT", "_m_d___m_a_x_panel__lib_8h.html#a804ff741ca21eab5b927d6dde890e3ca", null ],
    [ "MP_DEBUG", "_m_d___m_a_x_panel__lib_8h.html#aed1705e4091f3efb934e9e1a5a25fd22", null ],
    [ "PRINT", "_m_d___m_a_x_panel__lib_8h.html#a1696fc35fb931f8c876786fbc1078ac4", null ],
    [ "PRINTB", "_m_d___m_a_x_panel__lib_8h.html#a71d5d719d30a3cb9ec26a38c6cc6e269", null ],
    [ "PRINTS", "_m_d___m_a_x_panel__lib_8h.html#ad68f35c3cfe67be8d09d1cea8e788e13", null ],
    [ "PRINTX", "_m_d___m_a_x_panel__lib_8h.html#abf55b44e8497cbc3addccdeb294138cc", null ],
    [ "X2COL", "_m_d___m_a_x_panel__lib_8h.html#a96c842f0860ef1cd239981f2a97ce6ed", null ],
    [ "Y2ROW", "_m_d___m_a_x_panel__lib_8h.html#a88404f46bf4b6a604d34b28c324d8eed", null ]
];